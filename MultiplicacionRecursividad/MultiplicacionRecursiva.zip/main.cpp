/***********************************************************************
 * Module:  main.cpp
 * Author:  Andres Espin
 * Modified: Domingo, 26 de noviembre de 2023 22:40:40
 * Purpose: Multiplicacion Recursiva
 ***********************************************************************/
#include <iostream>
#include <conio.h>
#include <stdlib.h>
#include "Cproceso.cpp"
#include <time.h>

int main(){
	
	srand (time(NULL)); 
	Cproceso p;
	
    //Menu del Programa
    system("cls");
    printf("\t\tMultiplicacion de Matrices con datos random\n");
    p.encerarMatriz();
    p.llenarMatriz();
    p.imprimirMatriz(p.getMat1(), "A");
    cout << "\n";
    p.imprimirMatriz(p.getMat2(), "B");
    cout << "\n";
    p.multiplicacionRecursivaMatrices(p.getMat1(), p.getMat2(), p.getMatR(), 2, 2, 2);
    p.imprimirMatriz(p.getMatR(), "R");
    cout << "\nPulse enter para continuar\n"
         << endl;
    getch();

    system("pause");
    return 0;
}
